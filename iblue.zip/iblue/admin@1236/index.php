<!DOCTYPE html>
<html>
<head>
  <title>Phone Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    :root {
      --primary-color: #4361ee;
      --primary-dark: #3a56d4;
      --success-color: #2ecc71;
      --danger-color: #e74c3c;
      --warning-color: #f39c12;
      --light-bg: #f8f9fa;
      --dark-text: #2c3e50;
      --light-text: #7f8c8d;
      --border-radius: 12px;
      --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      --transition: all 0.3s ease;
    }

    body { 
      font-family: 'Segoe UI', Arial, sans-serif; 
      padding: 15px;
      max-width: 1200px;
      margin: 0 auto;
      background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      color: var(--dark-text);
      line-height: 1.6;
    }

    .container {
      display: grid;
      grid-template-columns: 1fr 2fr;
      gap: 25px;
    }

    .form-section, .preview-section, .export-import-section {
      background: white;
      padding: 25px;
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow);
      margin-bottom: 25px;
      transition: var(--transition);
    }

    .form-section:hover, .preview-section:hover, .export-import-section:hover {
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
      transform: translateY(-5px);
    }

    input, textarea, select { 
      display: block; 
      margin: 15px 0; 
      width: 100%;
      padding: 15px;
      border: 2px solid #e0e0e0;
      border-radius: var(--border-radius);
      font-size: 16px;
      background: var(--light-bg);
      transition: var(--transition);
    }

    input:focus, textarea:focus, select:focus {
      outline: none;
      border-color: var(--primary-color);
      background: white;
      box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
    }

    button {
      background: var(--primary-color);
      color: white;
      border: none;
      padding: 15px 25px;
      border-radius: var(--border-radius);
      cursor: pointer;
      margin: 10px 0;
      font-size: 16px;
      font-weight: 600;
      width: 100%;
      transition: var(--transition);
      position: relative;
      overflow: hidden;
    }

    button:hover {
      background: var(--primary-dark);
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
    }

    button:active {
      transform: translateY(0);
    }

    .phone-card { 
      margin: 25px 0;
      padding: 25px;
      border: none;
      border-radius: var(--border-radius);
      background: white;
      box-shadow: var(--box-shadow);
      transition: var(--transition);
      position: relative;
      overflow: hidden;
    }

    .phone-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .phone-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 5px;
      height: 100%;
      background: var(--primary-color);
      opacity: 0;
      transition: var(--transition);
    }

    .phone-card:hover::before {
      opacity: 1;
    }

    .phone-card img {
      width: 100%;
      height: auto;
      border-radius: var(--border-radius);
      margin: 20px 0;
      transition: var(--transition);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .phone-card:hover img {
      transform: scale(1.02);
    }

    .phone-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-top: 20px;
    }

    .delete-btn {
      background: var(--danger-color);
    }

    .delete-btn:hover {
      background: #c0392b;
    }

    .edit-btn {
      background: var(--success-color);
    }

    .edit-btn:hover {
      background: #27ae60;
    }

    .image-preview {
      width: 100%;
      max-height: 200px;
      object-fit: cover;
      border-radius: var(--border-radius);
      margin: 15px 0;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h1 {
      font-size: 32px;
      color: var(--dark-text);
      margin: 25px 0;
      text-align: center;
      position: relative;
      padding-bottom: 15px;
    }

    h1::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 100px;
      height: 4px;
      background: var(--primary-color);
      border-radius: 2px;
    }

    h2 {
      font-size: 24px;
      color: var(--dark-text);
      margin: 20px 0;
      position: relative;
      padding-bottom: 10px;
    }

    h2::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 50px;
      height: 3px;
      background: var(--primary-color);
      border-radius: 2px;
    }

    .phone-info {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-bottom: 20px;
    }

    .phone-name {
      font-size: 22px;
      font-weight: bold;
      color: var(--dark-text);
    }

    .phone-price {
      font-size: 24px;
      color: var(--success-color);
      font-weight: bold;
    }

    .phone-category {
      display: inline-block;
      padding: 8px 15px;
      background: rgba(67, 97, 238, 0.1);
      border-radius: 20px;
      font-size: 14px;
      color: var(--primary-color);
      align-self: flex-start;
      font-weight: 600;
    }

    .phone-description {
      color: var(--light-text);
      line-height: 1.6;
      margin: 15px 0;
      font-size: 16px;
    }

    .export-import-section {
      background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    }

    .export-import-section button {
      margin: 10px 0;
    }

    .export-import-section button:nth-child(1) {
      background: var(--primary-color);
    }

    .export-import-section button:nth-child(3) {
      background: var(--warning-color);
    }

    .export-import-section button:nth-child(3):hover {
      background: #e67e22;
    }

    .export-import-section button:nth-child(4) {
      background: var(--danger-color);
    }

    .export-import-section button:nth-child(4):hover {
      background: #c0392b;
    }

    /* Mobile Responsive Design */
    @media (max-width: 768px) {
      body {
        padding: 10px;
      }

      .container {
        grid-template-columns: 1fr;
      }

      h1 {
        font-size: 26px;
        margin: 20px 0;
      }

      h2 {
        font-size: 20px;
      }

      .form-section, .preview-section, .export-import-section {
        padding: 20px;
        margin-bottom: 20px;
      }

      input, textarea, select {
        padding: 12px;
        font-size: 16px;
      }

      button {
        padding: 12px 20px;
        font-size: 16px;
      }

      .phone-card {
        padding: 20px;
        margin: 20px 0;
      }

      .phone-name {
        font-size: 20px;
      }

      .phone-price {
        font-size: 22px;
      }

      .phone-category {
        font-size: 12px;
        padding: 6px 12px;
      }

      .phone-description {
        font-size: 15px;
      }
    }
  </style>
</head>
<body>
  <h1>Phone Management Dashboard</h1>
  
  <div class="container">
    <div class="form-section">
      <h2>Add/Edit Phone</h2>
      <form id="phoneForm" onsubmit="handleSubmit(event)">
        <input type="hidden" id="editIndex" value="-1">
        <select id="category" required>
          <option value="">Select Category</option>
          <option value="samsung">Samsung</option>
          <option value="iphone">iPhone</option>
          <option value="spark">Spark</option>
          <option value="realme">Realme</option>
        </select>
        <input type="text" id="name" placeholder="Phone Name" required>
        <input type="number" id="price" placeholder="Price" required>
        <textarea id="description" placeholder="Description" required></textarea>
        <input type="text" id="image" placeholder="Image URL" required onchange="previewImage(this.value)">
        <img id="imagePreview" class="image-preview" style="display: none;">
        <button type="submit" id="submitBtn">Add Phone</button>
        <button type="button" onclick="clearForm()" style="background: #6c757d;">Clear Form</button>
      </form>
    </div>

    <div class="preview-section">
      <h2>Phone List</h2>
      <div id="preview"></div>
    </div>
  </div>

  <div class="export-import-section">
    <button onclick="clearAllPhones()" style="background: #dc3545;">Clear All Phones</button>
  </div>

  <script>
    let phones = JSON.parse(localStorage.getItem('phones')) || [];

    function handleSubmit(event) {
      event.preventDefault();
      const editIndex = document.getElementById("editIndex").value;
      const imageUrl = document.getElementById("image").value.trim();
      
      // Validate image URL
      if (!imageUrl) {
        alert("Please enter a valid image URL");
        return;
      }
      
      const phone = {
        category: document.getElementById("category").value,
        name: document.getElementById("name").value,
        price: document.getElementById("price").value,
        description: document.getElementById("description").value,
        image: imageUrl,
      };

      if (editIndex === "-1") {
        phones.push(phone);
      } else {
        phones[editIndex] = phone;
      }

      savePhones();
      updatePreview();
      clearForm();
    }

    function updatePreview() {
      const container = document.getElementById("preview");
      container.innerHTML = '';
      phones.forEach((p, i) => {
        // Create a unique fallback image path based on category
        const fallbackImage = `../imgs/${p.category}.jpeg`;
        
        container.innerHTML += `
          <div class="phone-card">
            <div class="phone-info">
              <div class="phone-name">${p.name}</div>
              <div class="phone-price">$${p.price}</div>
              <span class="phone-category">${p.category}</span>
            </div>
            <img src="${p.image}" alt="${p.name}" onerror="this.onerror=null; this.src='${fallbackImage}';">
            <div class="phone-description">${p.description}</div>
            <div class="phone-actions">
              <button class="edit-btn" onclick="editPhone(${i})">Edit</button>
              <button class="delete-btn" onclick="deletePhone(${i})">Delete</button>
            </div>
          </div>`;
      });
    }

    function editPhone(index) {
      const phone = phones[index];
      document.getElementById("editIndex").value = index;
      document.getElementById("category").value = phone.category;
      document.getElementById("name").value = phone.name;
      document.getElementById("price").value = phone.price;
      document.getElementById("description").value = phone.description;
      document.getElementById("image").value = phone.image;
      document.getElementById("submitBtn").textContent = "Update Phone";
      previewImage(phone.image);
    }

    function deletePhone(index) {
      if (confirm("Are you sure you want to delete this phone?")) {
        phones.splice(index, 1);
        savePhones();
        updatePreview();
      }
    }

    function clearForm() {
      document.getElementById("phoneForm").reset();
      document.getElementById("editIndex").value = "-1";
      document.getElementById("submitBtn").textContent = "Add Phone";
      document.getElementById("imagePreview").style.display = "none";
    }

    function previewImage(url) {
      const preview = document.getElementById("imagePreview");
      preview.src = url;
      preview.style.display = "block";
      preview.onerror = function() {
        preview.style.display = "none";
        alert("Invalid image URL");
      };
    }

    function savePhones() {
      localStorage.setItem('phones', JSON.stringify(phones));
    }

    function downloadJSON() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(phones, null, 2));
      const dlAnchor = document.createElement('a');
      dlAnchor.setAttribute("href", dataStr);
      dlAnchor.setAttribute("download", "phones.json");
      document.body.appendChild(dlAnchor);
      dlAnchor.click();
      dlAnchor.remove();
    }

    function importJSON(event) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const importedPhones = JSON.parse(e.target.result);
          phones = importedPhones;
          savePhones();
          updatePreview();
          alert("Import successful!");
        } catch (error) {
          alert("Error importing file. Please make sure it's a valid JSON file.");
        }
      };
      reader.readAsText(file);
    }

    function clearAllPhones() {
      if (confirm("Are you sure you want to delete ALL phones? This action cannot be undone.")) {
        phones = [];
        savePhones();
        updatePreview();
        alert("All phones have been cleared successfully!");
      }
    }

    // Initial preview
    updatePreview();
  </script>
</body>
</html>
