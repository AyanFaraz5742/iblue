<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>IBlue - Home</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="icon" type="image/png" href="/iblue/logo.jpeg">
  <style>
    /* ... You can include your styles here ... */
  </style>
</head>
<body>

  <header>
    <div id="divstate">
      <h1 id="state">IBlue</h1>
    </div>

    <?php if (isset($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
      <div class="dashboard-btn-container">
        <a href="dashboard/index.html">
          <button class="dashboard-btn">Go to Dashboard</button>
        </a>
      </div>
    <?php endif; ?>
    <hr>
  </header>

  <main>
    <div class="phonepicdiv">
      <img class="phonepic" src="imgs/samsung.jpeg" alt="Samsung Galaxy S24">
    </div>
    <div class="phonebuttondiv">
      <a class="phonebutton" href="samsung/index.php" target="_blank">Samsung</a>
    </div>
    <hr>
    <div class="phonepicdiv">
      <img class="phonepic" src="imgs/iphone.jpeg" alt="iPhone Model">
    </div>
    <div class="phonebuttondiv">
      <a class="phonebutton" href="iphone/index.php" target="_blank">iPhone</a>
    </div>
    <hr>
    <div class="phonepicdiv">
      <img class="phonepic" src="imgs/spark.jpeg" alt="Spark and Realme">
    </div>
    <div class="phonebuttondiv">
      <a class="specialphonebutton" href="spark-and-realme/index.php" target="_blank">Spark And Realme</a>
    </div>
    <hr>
  </main>

  <footer>
    <div id="sponserdiv">
      <p id="sponser">&copy; 2025 Website From @Chikus</p>
    </div>
  </footer>

</body>
</html>
